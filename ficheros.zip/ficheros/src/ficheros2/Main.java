package ficheros2;

public class Main {

	public static void main(String[] args) {
		

	}
	static public void copiarLineas(String origen, String destino){
		
	}
}
