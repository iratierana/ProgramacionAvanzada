package puzzle;


public class Main {

	public static void main(String[] args) {
		Ventana window = new Ventana();
	}

}
