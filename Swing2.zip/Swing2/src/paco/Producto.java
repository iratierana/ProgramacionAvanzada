package paco;

public class Producto{

	String nombre;
	int precio;
	
	public Producto(String nombre, int precio) {
		super();
		this.nombre = nombre;
		this.precio = precio;
	}
}
