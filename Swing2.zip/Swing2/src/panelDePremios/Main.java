package panelDePremios;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Main extends JFrame implements ActionListener{

	JFrame ventana;
	JLabel texto;
	Boton[][] botones;
	JButton salir;
	int total = 0;
	
	final static int FILAS = 6;
	final static int COLUMNAS = 6;
	
	public static void main(String[] args) {
		Main ejercicio = new Main();
		
	}
	
	public Main(){
		ventana = new JFrame("Panel de premios");
		ventana.setSize(640, 480);
		ventana.setLocation(150,150);
		
		ventana.setContentPane(crearPanel());
		inicializar();
		ventana.setVisible(true);
		
	}

	private Container crearPanel() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBorder(BorderFactory.createEmptyBorder(10, 20, 40, 20));
		
		panel.add(crearText(), BorderLayout.NORTH);
		panel.add(crearMatriz(), BorderLayout.CENTER);
		panel.add(crearBoton(), BorderLayout.SOUTH);
		
		return panel;
	}
	private Component crearBoton() {
		salir = new JButton("Exit");
		salir.addActionListener(this);
		return salir;
	}

	private Component crearMatriz() {
		Random random = new Random();
		JPanel panel = new JPanel(new GridLayout(FILAS, COLUMNAS));
		
		botones = new Boton[FILAS][COLUMNAS];
		
		for (int i = 0; i < FILAS; i++) {
			for (int j = 0; j < COLUMNAS; j++) {
				botones[i][j] = new Boton(j, j);
				
				
			}
			
		}
		return panel;
	}

	private Component crearText() {
		texto = new JLabel("");
		return texto;
	}

	private void inicializar() {
		Random random = new Random();
		botones = new Boton[FILAS][COLUMNAS];
		int cont = 0;
		for(int i = 0 ; i < FILAS ; i++){
			for(int j = 0 ; j < COLUMNAS; j++){
				cont++;
				int valor = random.nextInt(35000);
				if(valor %2 == 1){
					valor  = 0;
				}
				botones[i][j] = new Boton(valor, cont);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
