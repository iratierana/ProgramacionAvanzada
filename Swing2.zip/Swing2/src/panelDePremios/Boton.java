package panelDePremios;

import javax.swing.JButton;

public class Boton {
	int valor;
	JButton boton;
	
	public Boton(int valor, int nombre) {
		super();
		this.valor = valor;
		boton = new JButton(String.valueOf(nombre));
	}
}


