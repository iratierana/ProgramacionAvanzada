package laberinto;

import java.util.Observable;

public class Pos {
	int x, y;

}
