package ejercicioUno;

public class Lavadora extends Dispositivo{

	public Lavadora(int parseInt, String string, String string2, int parseInt2, String string3, String string4,
			String string5, String string6) {
		super(parseInt, string, string2, parseInt2, string3, string4, string5, string6);
		// TODO Auto-generated constructor stub
	}

}
