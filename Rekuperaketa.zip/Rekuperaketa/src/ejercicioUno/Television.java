package ejercicioUno;

public class Television extends Dispositivo{

	public Television(int parseInt, String string, String string2, int parseInt2, String string3, String string4,
			String string5, String string6, String string7, String string8) {
		super(parseInt, string, string2, parseInt2, string3, string4, string5, string6, string7, string8);
		// TODO Auto-generated constructor stub
	}
	
	

}
