package ejercicioUno;

public class LamparaMesita extends Dispositivo{

	public LamparaMesita(int parseInt, String string, String string2) {
		super(parseInt, string, string2);
		// TODO Auto-generated constructor stub
	}

	
}
