package ejercicioUno;

public class LamparaTecho extends Dispositivo{

	public LamparaTecho(int parseInt, String string, String string2) {
		super(parseInt, string, string2);
		// TODO Auto-generated constructor stub
	}


}
