package ejercicioUno;

public class VitroFocoIS extends Dispositivo{
	
	public VitroFocoIS(int parseInt, String string, String string2, int parseInt2) {
		super(parseInt, string, string2, parseInt2);
		// TODO Auto-generated constructor stub
	}

}
