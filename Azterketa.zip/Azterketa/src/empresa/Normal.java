package empresa;

public class Normal extends Empleado{

	public Normal(int salario, String nombre) {
		super(salario, nombre);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Normal [salario=" + salario + ", nombre=" + nombre + "]";
	}

	
	
}
